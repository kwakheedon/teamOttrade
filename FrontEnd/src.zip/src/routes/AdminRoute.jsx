import React from 'react'
import { Routes } from 'react-router'

//관리자만 접근 가능하게 할 기능을 구현할 곳
const AdminRoute = () => {
  return (
    <Routes>
      AdminRoute
    </Routes>
  )
}

export default AdminRoute