import React from 'react'

const Loading = () => {
  return (
    <div>
        로딩중...
    </div>
  )
}

export default Loading