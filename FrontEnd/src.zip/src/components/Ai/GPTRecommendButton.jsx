import React from 'react'

//GPT 기반 유망 국가 추천을 요청할 버튼 컴포넌트
const GPTRecommendButton = () => {
  return (
    <div>GPTRecommendButton</div>
  )
}

export default GPTRecommendButton