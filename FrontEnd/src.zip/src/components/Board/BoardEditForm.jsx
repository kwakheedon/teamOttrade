import React from 'react'

//게시글 수정 폼 컴포넌트
const BoardEditForm = () => {
  return (
    <div>
      <h1>자유게시판</h1>

      {/* 기존의 게시글의 제목과 내용을 가져오기 */}

      {/* 수정 버튼 누르고 게시글 페이지로 이동 */}
      <button>수정</button>
    </div>
  )
}

export default BoardEditForm