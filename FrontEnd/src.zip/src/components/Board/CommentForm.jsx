import React from 'react'

//댓글 관련 컴포넌트를 담을 폼
const CommentForm = () => {
  return (
    <div>
      <input type="text" name="" id="" placeholder='댓글을 입력하세요'/>
    </div>
  )
}

export default CommentForm