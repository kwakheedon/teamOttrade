import React from 'react'

// 게시글 좋아요
const BoardRankBox = () => {
  return (
    <div>BoardRankBox</div>
  )
}

export default BoardRankBox