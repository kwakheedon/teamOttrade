import React from 'react'

//수출입 토글 버튼 컴포넌트
const ToggleExportImport = () => {
  return (
    <div>ToggleExportImport</div>
  )
}

export default ToggleExportImport