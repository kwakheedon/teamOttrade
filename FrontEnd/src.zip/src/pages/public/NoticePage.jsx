import React from 'react'
import './NoticePage.css'

//공지사항 페이지
const NoticePage = () => {
  return (
    <div className="notice-container">
      <h1 className='board-title'>공지사항</h1>

      {/* 공지사항 목록 */}

    </div>
  )
}

export default NoticePage